<?xml version="1.0" encoding="UTF-8"?>
<!--

	GP Data Schematro Rules


CHANGE LOG:

0.74 Add mandatory single patient-table/pt check in response to relaxation of patient-extract-snapshot sequence constraints in schema
0.74 Added practitioner professional_identfier and issuing_body co-appearance constraint
0.74 Added patient postcode_secctor and postcode_deid dependency
0.74 Added patient lsoa and postcode_deid dependency
0.74 Codeable Concept - other_expression ote can appear standalone without other_code, other_display and other_code_system
0.75 Fixed incorrect @od for additional codeable concept types
0.75 Remove co-occurrence rule for interpreter-required and preferred language from patient table
0.76 Removed patient cardinality rule - now enforced by schema
0.77 No change just updated version to align with schema version

-->
<iso:schema xmlns="http://purl.oclc.org/dsdl/schematron"
	xmlns:iso="http://purl.oclc.org/dsdl/schematron" 
	xmlns:dp="http://www.dpawson.co.uk/ns#" 
	queryBinding="xslt2" schemaVersion="ISO19757-3">
	one
    <iso:title>GP Data Schematron</iso:title>
    <iso:ns prefix="dp" uri="http://www.dpawson.co.uk/ns#"/>
    <iso:ns prefix="gp" uri="http://www.nhsdigital.nhs.uk/GPDFSU/XMLSchema/GPDataExtract/ns"/>    
    
    <!-- Your constraints go here -->
    <iso:pattern>
		<iso:rule context="gp:patient-extract-snapshot">
			<iso:assert test="@patient-id-deid or @local-id-deid">One of or both of patient-id-deid or local-id-deid must be present '<value-of select="./@id"/>'</iso:assert>
		</iso:rule>
  

		<iso:rule context="gp:ort">
			<iso:assert test="@nm or @oc">One of or both of the organisation name or ODS code must be present' <value-of select="./@id"/>'</iso:assert>									
		</iso:rule>  
		
		
		<iso:rule context="gp:prct">
			<iso:report test="@ib and not(@pi)">If identifier_issuing_body @ib is supplied then professional identifer @pi must be supplied '<value-of select="./@id"/>'</iso:report>	
			<iso:report test="@pi and not(@ib)">If professional identifer @pi is supplied then identifier_issuing_body @ib must be supplied '<value-of select="./@id"/>'</iso:report>										
		</iso:rule>		
  
   	
		<iso:rule context="gp:pt">
			<iso:assert test="@pidd or @lid">One of or both of pidd or lid must be present '<value-of select="./@id"/>'</iso:assert>
			<iso:report test="@wd and not(@ddd)">If there is a date of death available then both @wd and @ddd must be supplied '<value-of select="./@id"/>'</iso:report>	
			<iso:report test="@ddd and not(@wd)">If there is a date of death available then both @wd and @ddd must be supplied '<value-of select="./@id"/>'</iso:report>	
			<iso:report test="@ps and not(@pd)">If postcode_sector @ps is specified then postcode_deid @pd must be supplied '<value-of select="./@id"/>'</iso:report>
			<iso:report test="@lsoa and not(@pd)">If lsoa @lsoa is specified then postcode_deid @pd must be supplied '<value-of select="./@id"/>'</iso:report>																		
		</iso:rule>


        <iso:rule context="gp:et">
            <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Concept ID supplied' <value-of select="./@id"/>'</iso:report>                                                                                 
        </iso:rule>

    
        <iso:rule context="gp:ot">
            <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied' <value-of select="./@id"/>'</iso:report>    
            
                                                        
            <iso:report test="@uu and not(@um)">If Ucum units are supplied then non ucum must be supplied as well' <value-of select="./@id"/>'</iso:report>  
            <iso:report test="@v2 and not(@v1)">If Value-PQ-2 supplied then Value-PQ-1 is expected' <value-of select="./@id"/>'</iso:report> 

            <iso:report test="@ith='true' and @tid">A template header should not link to a template' <value-of select="./@id"/>'</iso:report> 
            <iso:report test="@tid = @id">A Template-ID reference should not point to the same statement ' <value-of select="./@id"/></iso:report> 


            <iso:report test="@v-oc and not(@v-ocs and @v-od)">Value Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@v-ocs and not(@v-oc and @v-od)">Value Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@v-od and not(@v-oc and @v-ocs)">Value Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@v-us='ctv3' and not(@v-ctv3)">Value Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@v-us='rvt' and not(@v-rct)">Value Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@v-us='sct' and not(@v-cid)">Value Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@v-us='other' and not(@v-oc)">Value Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@v-sce and not(@v-cid)">Value Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@v-did and not(@v-cid)">Value Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>     


  
                                                                                        
        </iso:rule>

        <iso:rule context="gp:it">
        
        
            <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>           
        
                                          
            <iso:report test="@ud and not(@um)">If DMD units are supplied then non ucum must be supplied as well '<value-of select="./@id"/>'</iso:report>  
            
     
            <iso:report test="@s-oc and not(@s-ocs and @s-od)">Substance Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@s-ocs and not(@s-oc and @s-od)">Substance Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@s-od and not(@s-oc and @s-ocs)">Substance Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@s-us='ctv3' and not(@s-ctv3)">Substance Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@s-us='rvt' and not(@s-rct)">Substance Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@s-us='sct' and not(@s-cid)">Substance Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@s-us='other' and not(@s-oc)">Substance Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@s-sce and not(@s-cid)">Substance Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@s-did and not(@s-cid)">Substance Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>               
        
            
      </iso:rule>
      
      <iso:rule context="gp:rt">
            <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>                                              
        </iso:rule>
      
		<iso:rule context="gp:prt">

            <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>      


            <iso:report test="@pi and not(@rl)">Relationship required if Problem relates to another Problem '<value-of select="./@id"/>'</iso:report>
            <iso:report test="@rl and not(@pi)">Problem Id link required if Problem relates to another Problem '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@pi = @id">Problem should not refer to itself '<value-of select="./@id"/>'</iso:report>   
                                                                               
        </iso:rule>	
        
     
		<iso:rule context="gp:rft">
            <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>                                                         
        </iso:rule>	
       
      
       

        
         
                
        <iso:rule context="gp:at">
          
           <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>           
        
            
            <iso:report test="@r-oc and not(@r-ocs and @r-od)">Reaction Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@r-ocs and not(@r-oc and @r-od)">Reaction Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@r-od and not(@r-oc and @r-ocs)">Reaction Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@r-us='ctv3' and not(@r-ctv3)">Reaction Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@r-us='rvt' and not(@r-rct)">Reaction Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@r-us='sct' and not(@r-cid)">Reaction Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@r-us='other' and not(@r-oc)">Reaction Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@r-sce and not(@r-cid)">Reaction Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@r-did and not(@r-cid)">Reaction Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>    
                                          

            
          
                                                                                         
        </iso:rule>
        
     
                        
        <iso:rule context="gp:mt">

           <iso:report test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>    

            <iso:report test="@st-oc and not(@st-ocs and @st-od)">Stop Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@st-ocs and not(@st-oc and @st-od)">Stop Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@st-od and not(@st-oc and @st-ocs)">Stop Codeable Concept: All attributes for other codes must be present if any are present '<value-of select="./@id"/>'</iso:report>            
            <iso:report test="@st-us='ctv3' and not(@st-ctv3)">Stop Codeable Concept: 1 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report> 
            <iso:report test="@st-us='rvt' and not(@st-rct)">Stop Codeable Concept: 2 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>  
            <iso:report test="@st-us='sct' and not(@st-cid)">Stop Codeable Concept: 3 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>   
            <iso:report test="@st-us='other' and not(@st-oc)">Stop Codeable Concept: 4 User selected points to a code that does not exist '<value-of select="./@id"/>'</iso:report>                                              
            <iso:report test="@st-sce and not(@st-cid)">Stop Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<value-of select="./@id"/>'</iso:report>    
            <iso:report test="@st-did and not(@st-cid)">Stop Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<value-of select="./@id"/>'</iso:report>  
           
            <iso:report test="@in='plan' and @aid">Medication Authorisation should not have an authorisation link' <value-of select="./@id"/>'</iso:report>         
            <iso:report test="@in='order' and not(@aid)">Medication Issue must have an authorisation' <value-of select="./@id"/>'</iso:report>
            <iso:report test="@in='order' and @st != 'completed'">Medication issues must have status complete' <value-of select="./@id"/>'</iso:report>        
            <iso:report test="@aid = @id">Medication Authorisation cannot link to same Medication ' <value-of select="./@id"/>'</iso:report>  </iso:rule>        
  


  </iso:pattern>
    
    

  

    
</iso:schema>