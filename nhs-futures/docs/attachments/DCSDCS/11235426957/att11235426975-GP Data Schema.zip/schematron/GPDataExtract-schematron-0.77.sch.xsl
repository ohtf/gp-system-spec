<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<xsl:stylesheet xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:saxon="http://saxon.sf.net/"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:schold="http://www.ascc.net/xml/schematron"
                xmlns:iso="http://purl.oclc.org/dsdl/schematron"
                xmlns:xhtml="http://www.w3.org/1999/xhtml"
                xmlns:dp="http://www.dpawson.co.uk/ns#"
                xmlns:gp="http://www.nhsdigital.nhs.uk/GPDFSU/XMLSchema/GPDataExtract/ns"
                version="2.0"><!--Implementers: please note that overriding process-prolog or process-root is 
    the preferred method for meta-stylesheets to use where possible. -->
   <xsl:param name="archiveDirParameter"/>
   <xsl:param name="archiveNameParameter"/>
   <xsl:param name="fileNameParameter"/>
   <xsl:param name="fileDirParameter"/>
   <xsl:variable name="document-uri">
      <xsl:value-of select="document-uri(/)"/>
   </xsl:variable>
   <!--PHASES-->
   <!--PROLOG-->
   <!--XSD TYPES FOR XSLT2-->
   <!--KEYS AND FUNCTIONS-->
   <!--DEFAULT RULES-->
   <!--MODE: SCHEMATRON-SELECT-FULL-PATH-->
   <!--This mode can be used to generate an ugly though full XPath for locators-->
   <xsl:template match="*" mode="schematron-select-full-path">
      <xsl:apply-templates select="." mode="schematron-get-full-path"/>
   </xsl:template>
   <!--MODE: SCHEMATRON-FULL-PATH-->
   <!--This mode can be used to generate an ugly though full XPath for locators-->
   <xsl:template match="*" mode="schematron-get-full-path">
      <xsl:apply-templates select="parent::*" mode="schematron-get-full-path"/>
      <xsl:text>/</xsl:text>
      <xsl:choose>
         <xsl:when test="namespace-uri()=''">
            <xsl:value-of select="name()"/>
         </xsl:when>
         <xsl:otherwise>
            <xsl:text>*:</xsl:text>
            <xsl:value-of select="local-name()"/>
            <xsl:text>[namespace-uri()='</xsl:text>
            <xsl:value-of select="namespace-uri()"/>
            <xsl:text>']</xsl:text>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:variable name="preceding"
                    select="count(preceding-sibling::*[local-name()=local-name(current())                                   and namespace-uri() = namespace-uri(current())])"/>
      <xsl:text>[</xsl:text>
      <xsl:value-of select="1+ $preceding"/>
      <xsl:text>]</xsl:text>
   </xsl:template>
   <xsl:template match="@*" mode="schematron-get-full-path">
      <xsl:apply-templates select="parent::*" mode="schematron-get-full-path"/>
      <xsl:text>/</xsl:text>
      <xsl:choose>
         <xsl:when test="namespace-uri()=''">@<xsl:value-of select="name()"/>
         </xsl:when>
         <xsl:otherwise>
            <xsl:text>@*[local-name()='</xsl:text>
            <xsl:value-of select="local-name()"/>
            <xsl:text>' and namespace-uri()='</xsl:text>
            <xsl:value-of select="namespace-uri()"/>
            <xsl:text>']</xsl:text>
         </xsl:otherwise>
      </xsl:choose>
   </xsl:template>
   <!--MODE: SCHEMATRON-FULL-PATH-2-->
   <!--This mode can be used to generate prefixed XPath for humans-->
   <xsl:template match="node() | @*" mode="schematron-get-full-path-2">
      <xsl:for-each select="ancestor-or-self::*">
         <xsl:text>/</xsl:text>
         <xsl:value-of select="name(.)"/>
         <xsl:if test="preceding-sibling::*[name(.)=name(current())]">
            <xsl:text>[</xsl:text>
            <xsl:value-of select="count(preceding-sibling::*[name(.)=name(current())])+1"/>
            <xsl:text>]</xsl:text>
         </xsl:if>
      </xsl:for-each>
      <xsl:if test="not(self::*)">
         <xsl:text/>/@<xsl:value-of select="name(.)"/>
      </xsl:if>
   </xsl:template>
   <!--MODE: SCHEMATRON-FULL-PATH-3-->
   <!--This mode can be used to generate prefixed XPath for humans 
	(Top-level element has index)-->
   <xsl:template match="node() | @*" mode="schematron-get-full-path-3">
      <xsl:for-each select="ancestor-or-self::*">
         <xsl:text>/</xsl:text>
         <xsl:value-of select="name(.)"/>
         <xsl:if test="parent::*">
            <xsl:text>[</xsl:text>
            <xsl:value-of select="count(preceding-sibling::*[name(.)=name(current())])+1"/>
            <xsl:text>]</xsl:text>
         </xsl:if>
      </xsl:for-each>
      <xsl:if test="not(self::*)">
         <xsl:text/>/@<xsl:value-of select="name(.)"/>
      </xsl:if>
   </xsl:template>
   <!--MODE: GENERATE-ID-FROM-PATH -->
   <xsl:template match="/" mode="generate-id-from-path"/>
   <xsl:template match="text()" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.text-', 1+count(preceding-sibling::text()), '-')"/>
   </xsl:template>
   <xsl:template match="comment()" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.comment-', 1+count(preceding-sibling::comment()), '-')"/>
   </xsl:template>
   <xsl:template match="processing-instruction()" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.processing-instruction-', 1+count(preceding-sibling::processing-instruction()), '-')"/>
   </xsl:template>
   <xsl:template match="@*" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.@', name())"/>
   </xsl:template>
   <xsl:template match="*" mode="generate-id-from-path" priority="-0.5">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:text>.</xsl:text>
      <xsl:value-of select="concat('.',name(),'-',1+count(preceding-sibling::*[name()=name(current())]),'-')"/>
   </xsl:template>
   <!--MODE: GENERATE-ID-2 -->
   <xsl:template match="/" mode="generate-id-2">U</xsl:template>
   <xsl:template match="*" mode="generate-id-2" priority="2">
      <xsl:text>U</xsl:text>
      <xsl:number level="multiple" count="*"/>
   </xsl:template>
   <xsl:template match="node()" mode="generate-id-2">
      <xsl:text>U.</xsl:text>
      <xsl:number level="multiple" count="*"/>
      <xsl:text>n</xsl:text>
      <xsl:number count="node()"/>
   </xsl:template>
   <xsl:template match="@*" mode="generate-id-2">
      <xsl:text>U.</xsl:text>
      <xsl:number level="multiple" count="*"/>
      <xsl:text>_</xsl:text>
      <xsl:value-of select="string-length(local-name(.))"/>
      <xsl:text>_</xsl:text>
      <xsl:value-of select="translate(name(),':','.')"/>
   </xsl:template>
   <!--Strip characters-->
   <xsl:template match="text()" priority="-1"/>
   <!--SCHEMA SETUP-->
   <xsl:template match="/">
      <xsl:apply-templates select="/" mode="M3"/>
   </xsl:template>
   <!--SCHEMATRON PATTERNS-->
   <!--PATTERN -->
   <!--RULE -->
   <xsl:template match="gp:patient-extract-snapshot" priority="1011" mode="M3">

		<!--ASSERT -->
      <xsl:choose>
         <xsl:when test="@patient-id-deid or @local-id-deid"/>
         <xsl:otherwise>One of or both of patient-id-deid or local-id-deid must be present '<xsl:text/>
            <xsl:value-of select="./@id"/>
            <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:ort" priority="1010" mode="M3">

		<!--ASSERT -->
      <xsl:choose>
         <xsl:when test="@nm or @oc"/>
         <xsl:otherwise>One of or both of the organisation name or ODS code must be present' <xsl:text/>
            <xsl:value-of select="./@id"/>
            <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:prct" priority="1009" mode="M3">

		<!--REPORT -->
      <xsl:if test="@ib and not(@pi)">If identifier_issuing_body @ib is supplied then professional identifer @pi must be supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@pi and not(@ib)">If professional identifer @pi is supplied then identifier_issuing_body @ib must be supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:pt" priority="1008" mode="M3">

		<!--ASSERT -->
      <xsl:choose>
         <xsl:when test="@pidd or @lid"/>
         <xsl:otherwise>One of or both of pidd or lid must be present '<xsl:text/>
            <xsl:value-of select="./@id"/>
            <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
         </xsl:otherwise>
      </xsl:choose>
      <!--REPORT -->
      <xsl:if test="@wd and not(@ddd)">If there is a date of death available then both @wd and @ddd must be supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ddd and not(@wd)">If there is a date of death available then both @wd and @ddd must be supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ps and not(@pd)">If postcode_sector @ps is specified then postcode_deid @pd must be supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@lsoa and not(@pd)">If lsoa @lsoa is specified then postcode_deid @pd must be supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:et" priority="1007" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Concept ID supplied' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:ot" priority="1006" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@uu and not(@um)">If Ucum units are supplied then non ucum must be supplied as well' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v2 and not(@v1)">If Value-PQ-2 supplied then Value-PQ-1 is expected' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ith='true' and @tid">A template header should not link to a template' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@tid = @id">A Template-ID reference should not point to the same statement ' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>
         <xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-oc and not(@v-ocs and @v-od)">Value Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-ocs and not(@v-oc and @v-od)">Value Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-od and not(@v-oc and @v-ocs)">Value Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-us='ctv3' and not(@v-ctv3)">Value Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-us='rvt' and not(@v-rct)">Value Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-us='sct' and not(@v-cid)">Value Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-us='other' and not(@v-oc)">Value Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-sce and not(@v-cid)">Value Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@v-did and not(@v-cid)">Value Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:it" priority="1005" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ud and not(@um)">If DMD units are supplied then non ucum must be supplied as well '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-oc and not(@s-ocs and @s-od)">Substance Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-ocs and not(@s-oc and @s-od)">Substance Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-od and not(@s-oc and @s-ocs)">Substance Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-us='ctv3' and not(@s-ctv3)">Substance Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-us='rvt' and not(@s-rct)">Substance Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-us='sct' and not(@s-cid)">Substance Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-us='other' and not(@s-oc)">Substance Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-sce and not(@s-cid)">Substance Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@s-did and not(@s-cid)">Substance Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:rt" priority="1004" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:prt" priority="1003" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@pi and not(@rl)">Relationship required if Problem relates to another Problem '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@rl and not(@pi)">Problem Id link required if Problem relates to another Problem '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@pi = @id">Problem should not refer to itself '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:rft" priority="1002" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:at" priority="1001" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-oc and not(@r-ocs and @r-od)">Reaction Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-ocs and not(@r-oc and @r-od)">Reaction Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-od and not(@r-oc and @r-ocs)">Reaction Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-us='ctv3' and not(@r-ctv3)">Reaction Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-us='rvt' and not(@r-rct)">Reaction Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-us='sct' and not(@r-cid)">Reaction Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-us='other' and not(@r-oc)">Reaction Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-sce and not(@r-cid)">Reaction Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@r-did and not(@r-cid)">Reaction Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="gp:mt" priority="1000" mode="M3">

		<!--REPORT -->
      <xsl:if test="@oc and not(@ocs and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@ocs and not(@oc and @od)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@od and not(@oc and @ocs)">Main Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='ctv3' and not(@ctv3)">Main Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='rvt' and not(@rct)">Main Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='sct' and not(@cid)">Main Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@us='other' and not(@oc)">Main Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@sce and not(@cid)">Main Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@did and not(@cid)">Main Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-oc and not(@st-ocs and @st-od)">Stop Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-ocs and not(@st-oc and @st-od)">Stop Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-od and not(@st-oc and @st-ocs)">Stop Codeable Concept: All attributes for other codes must be present if any are present '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-us='ctv3' and not(@st-ctv3)">Stop Codeable Concept: 1 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-us='rvt' and not(@st-rct)">Stop Codeable Concept: 2 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-us='sct' and not(@st-cid)">Stop Codeable Concept: 3 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-us='other' and not(@st-oc)">Stop Codeable Concept: 4 User selected points to a code that does not exist '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-sce and not(@st-cid)">Stop Codeable Concept: If an SCT expression is supplied then the SCT Concept Id Must Be Supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@st-did and not(@st-cid)">Stop Codeable Concept: Both SCT Concept Id and Descriptor must be supplied if SCT Descriptor ID supplied '<xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@in='plan' and @aid">Medication Authorisation should not have an authorisation link' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@in='order' and not(@aid)">Medication Issue must have an authorisation' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@in='order' and @st != 'completed'">Medication issues must have status complete' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <!--REPORT -->
      <xsl:if test="@aid = @id">Medication Authorisation cannot link to same Medication ' <xsl:text/>
         <xsl:value-of select="./@id"/>
         <xsl:text/>'<xsl:value-of select="string('&#xA;')"/>
      </xsl:if>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
   <xsl:template match="text()" priority="-1" mode="M3"/>
   <xsl:template match="@*|node()" priority="-2" mode="M3">
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M3"/>
   </xsl:template>
</xsl:stylesheet>
